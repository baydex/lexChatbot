"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.intents = void 0;
exports.intents = {
    "Validar_correo": {
        "Guardar_correo": null,
    },
    "Buscar_dispositivo": {
        "Alias": null,
        "Error": null,
    },
    "Enviar_reset": {
        "Verificar": null,
    },
    "Generar_ticket": {
        "Final": null,
    },
};
//# sourceMappingURL=intents.js.map